
import {KafkaTopics} from "./kafkaTopics";
import {UserService} from '../service/user.service'
import {server} from "../server";

const UserServiceInc = new UserService();
// @ts-ignore
server.kafka.subscribe([KafkaTopics.insert_user]);

// @ts-ignore
server.kafka.on(KafkaTopics.insert_user, (msg: any, commit: any) => {
    console.log('log:::::insert_user', JSON.stringify(msg))
    UserServiceInc.createUser({})
    commit()
})