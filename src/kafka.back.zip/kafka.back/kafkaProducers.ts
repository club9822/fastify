
import {KafkaTopics} from "./kafkaTopics";
import {server} from "../server";

export const userPub = (payload:any) => {
    // @ts-ignore
    server.kafka.push({
        topic: KafkaTopics.insert_user,
        payload: payload,
        key: 'dataKey'
    } as any)
}
