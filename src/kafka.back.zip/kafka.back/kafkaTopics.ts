export enum KafkaTopics {
    "insert_user"="insert_user",
    "update_user"="update_user",
}